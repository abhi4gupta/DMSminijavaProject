module Document {
    requires javafx.fxml;
    requires javafx.controls;
    requires jdk.compiler;
    opens sample;
    //opens Signup;
}
